import json
import logging
import os
import sys
import uuid
from datetime import datetime
from decimal import Decimal

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shared.dynamodb import get_carts_table as shared_get_carts_table
from shared.dynamodb import get_products_table as shared_get_products_table
from shared.logger import get_logger, log_event
from shared.response import error_response, success_response
from shared.validators import ValidationError, parse_positive_int, validate_required_fields

logger = get_logger(__name__)


def get_correlation_id(event):
    headers = event.get('headers') or {}
    return headers.get('x-correlation-id') or headers.get('X-Correlation-Id') or str(uuid.uuid4())


def get_carts_table():
    return shared_get_carts_table()


def get_products_table():
    return shared_get_products_table()


def build_cart_payload(user_id, cart, message):
    return {
        'message': message,
        'data': {
            'user_id': user_id,
            'items': cart.get('items', {}),
            'total_items': cart.get('total_items', 0),
            'total_price': cart.get('total_price', 0),
            'created_at': cart.get('created_at'),
            'updated_at': cart.get('updated_at')
        }
    }


def normalize_cart_items(items):
    """Accept cart items stored as a mapping or a list and normalize to a mapping."""
    if isinstance(items, dict):
        return items

    if not isinstance(items, list):
        raise ValueError("Cart items must be an object or list")

    normalized_items = {}
    for item in items:
        product_id = str(item.get('product_id', item.get('product')))
        if not product_id or product_id == 'None':
            raise ValueError("Cart item is missing product_id")

        quantity = int(item.get('quantity', 0))
        unit_price = Decimal(str(item.get('unit_price', item.get('price', 0))))
        total_price = Decimal(str(item.get('total_price', unit_price * quantity)))

        normalized_items[product_id] = {
            'product_id': product_id,
            'product_name': item.get('product_name', item.get('product', product_id)),
            'unit_price': unit_price,
            'quantity': quantity,
            'total_price': total_price
        }

    return normalized_items


def normalize_cart(cart, user_id):
    normalized_cart = dict(cart)
    normalized_cart['user_id'] = user_id
    normalized_cart['items'] = normalize_cart_items(cart.get('items', {}))
    normalized_cart['created_at'] = cart.get('created_at')
    normalized_cart['updated_at'] = cart.get('updated_at')
    return normalized_cart


def get_cart_route_parts(path):
    """Return route parts after the cart segment for /cart and /v1/cart paths."""
    parts = [part for part in path.split('/') if part]
    if len(parts) >= 2 and parts[0] == 'v1' and parts[1] == 'cart':
        return parts[2:]
    if parts and parts[0] == 'cart':
        return parts[1:]
    return []


def recalculate_cart_totals(cart):
    cart['total_items'] = sum(item['quantity'] for item in cart['items'].values())
    cart['total_price'] = sum(item['total_price'] for item in cart['items'].values())
    return cart


def lambda_handler(event, context):
    """
    Cart Lambda Handler
    Routes: GET, POST, PUT, DELETE /cart
    """

    http_method = event.get('requestContext', {}).get('http', {}).get('method', 'GET')
    path = event.get('rawPath', '/')
    route_parts = get_cart_route_parts(path)
    correlation_id = get_correlation_id(event)
    log_event(
        logger,
        logging.INFO,
        "cart_request_received",
        service="cart",
        action=http_method,
        path=path,
        correlation_id=correlation_id
    )

    try:
        # POST /cart - Add item to cart
        if http_method == 'POST' and len(route_parts) == 0:
            body = json.loads(event.get('body', '{}'))
            return add_to_cart(body, correlation_id)

        # GET /cart/{user_id} - Get user's cart
        elif http_method == 'GET' and len(route_parts) == 1:
            user_id = route_parts[0]
            return get_cart(user_id, correlation_id)

        # PUT /cart/{user_id}/{product_id} - Update quantity
        elif http_method == 'PUT' and len(route_parts) == 2:
            user_id, product_id = route_parts
            body = json.loads(event.get('body', '{}'))
            return update_cart_item(user_id, product_id, body, correlation_id)

        # DELETE /cart/{user_id}/{product_id} - Remove item
        elif http_method == 'DELETE' and len(route_parts) == 2:
            user_id, product_id = route_parts
            return remove_from_cart(user_id, product_id, correlation_id)

        # DELETE /cart/{user_id} - Clear entire cart
        elif http_method == 'DELETE' and len(route_parts) == 1:
            user_id = route_parts[0]
            return clear_cart(user_id, correlation_id)

        else:
            return error_response(400, "Invalid request", correlation_id)

    except json.JSONDecodeError:
        logger.warning("Invalid JSON request body")
        return error_response(400, "Invalid JSON request body", correlation_id)
    except Exception as e:
        logger.exception("Unhandled cart request error")
        return error_response(500, f"Internal server error: {str(e)}", correlation_id)


def add_to_cart(body, correlation_id=None):
    """Add item to user's cart"""
    required_fields = ['user_id', 'product_id', 'quantity']

    try:
        validate_required_fields(body, required_fields)
        carts_table = get_carts_table()
        products_table = get_products_table()   
        user_id = str(body['user_id'])
        product_id = str(body['product_id'])
        quantity = parse_positive_int(body['quantity'], 'Quantity')

        # Verify product exists
        product_response = products_table.get_item(Key={'product_id': product_id})
        if 'Item' not in product_response:
            return error_response(404, f"Product {product_id} not found", correlation_id)

        product = product_response['Item']

        # Get or create cart
        cart_response = carts_table.get_item(Key={'user_id': user_id})
        cart = cart_response.get('Item', {
            'user_id': user_id,
            'items': {},
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        })
        cart = normalize_cart(cart, user_id)

        current_item = cart['items'].get(product_id)
        next_quantity = quantity
        if current_item:
            next_quantity = int(current_item.get('quantity', 0)) + quantity
        log_event(
            logger,
            logging.INFO,
            "cart_quantity_add",
            service="cart",
            action="add_to_cart",
            user_id=user_id,
            product_id=product_id,
            requested_quantity=quantity,
            previous_quantity=int(current_item.get('quantity', 0)) if current_item else 0,
            next_quantity=next_quantity,
            correlation_id=correlation_id
        )

        # Add or update item in cart. POST means "add this quantity", not "set absolute quantity".
        cart['items'][product_id] = {
            'product_id': product_id,
            'product_name': product['name'],
            'unit_price': product['price'],  # Keep as Decimal
            'quantity': next_quantity,
            'total_price': product['price'] * next_quantity  # Keep as Decimal
        }

        cart['updated_at'] = datetime.now().isoformat()
        recalculate_cart_totals(cart)

        carts_table.put_item(Item=cart)

        return success_response(200, {
            'message': f'Added {quantity} of {product["name"]} to cart',
            'data': cart
        }, correlation_id)

    except ValidationError as e:
        return error_response(400, str(e), correlation_id)
    except Exception as e:
        logger.exception("Failed to add to cart")
        return error_response(500, f"Failed to add to cart: {str(e)}", correlation_id)


def get_cart(user_id, correlation_id=None):
    """Get user's cart"""
    try:
        carts_table = get_carts_table()
        response = carts_table.get_item(Key={'user_id': user_id})

        if 'Item' not in response:
            # Return empty cart
            empty_cart = {
                'user_id': user_id,
                'items': {},
                'total_items': 0,
                'total_price': 0,
                'created_at': None,
                'updated_at': None
            }
            return success_response(200, build_cart_payload(user_id, empty_cart, 'Cart is empty'), correlation_id)

        cart = normalize_cart(response['Item'], user_id)
        return success_response(200, build_cart_payload(user_id, cart, f"Retrieved cart for {user_id}"), correlation_id)

    except Exception as e:
        logger.exception("Failed to retrieve cart")
        return error_response(500, f"Failed to retrieve cart: {str(e)}", correlation_id)


def update_cart_item(user_id, product_id, body, correlation_id=None):
    """Update quantity of item in cart"""
    try:
        carts_table = get_carts_table()
        products_table = get_products_table()
        validate_required_fields(body, ['quantity'])
        quantity = parse_positive_int(body.get('quantity'), 'Quantity')

        # Get cart
        response = carts_table.get_item(Key={'user_id': user_id})
        if 'Item' not in response:
            return error_response(404, "Cart not found", correlation_id)

        cart = normalize_cart(response['Item'], user_id)

        if product_id not in cart['items']:
            return error_response(404, f"Product not in cart", correlation_id)

        # Get product price
        product_response = products_table.get_item(Key={'product_id': product_id})
        if 'Item' not in product_response:
            return error_response(404, "Product not found", correlation_id)

        product = product_response['Item']

        # Update item
        previous_quantity = int(cart['items'][product_id].get('quantity', 0))
        cart['items'][product_id]['quantity'] = quantity
        cart['items'][product_id]['total_price'] = product['price'] * quantity
        cart['updated_at'] = datetime.now().isoformat()

        recalculate_cart_totals(cart)

        carts_table.put_item(Item=cart)
        log_event(
            logger,
            logging.INFO,
            "cart_quantity_update",
            service="cart",
            action="update_quantity",
            user_id=user_id,
            product_id=product_id,
            previous_quantity=previous_quantity,
            next_quantity=quantity,
            correlation_id=correlation_id
        )

        return success_response(200, {
            'message': f'Updated quantity for {product_id}',
            'data': cart
        }, correlation_id)

    except ValidationError as e:
        return error_response(400, str(e), correlation_id)
    except Exception as e:
        logger.exception("Failed to update cart")
        return error_response(500, f"Failed to update cart: {str(e)}", correlation_id)


def remove_from_cart(user_id, product_id, correlation_id=None):
    """Remove item from cart"""
    try:
        carts_table = get_carts_table()
        # products_table = get_products_table()
        response = carts_table.get_item(Key={'user_id': user_id})
        if 'Item' not in response:
            return error_response(404, "Cart not found", correlation_id)

        cart = normalize_cart(response['Item'], user_id)

        if product_id not in cart['items']:
            return error_response(404, f"Product not in cart", correlation_id)

        # Remove item
        product_name = cart['items'][product_id]['product_name']
        del cart['items'][product_id]
        cart['updated_at'] = datetime.now().isoformat()

        recalculate_cart_totals(cart)

        carts_table.put_item(Item=cart)
        log_event(logger, logging.INFO, "cart_item_removed", service="cart", action="remove_from_cart", user_id=user_id, product_id=product_id, correlation_id=correlation_id)

        return success_response(200, {
            'message': f'Removed {product_name} from cart',
            'data': cart
        }, correlation_id)

    except Exception as e:
        logger.exception("Failed to remove from cart")
        return error_response(500, f"Failed to remove from cart: {str(e)}", correlation_id)


def clear_cart(user_id, correlation_id=None):
    """Clear entire cart"""
    try:
        carts_table = get_carts_table()
        carts_table.delete_item(Key={'user_id': user_id})
        log_event(logger, logging.INFO, "cart_cleared", service="cart", action="clear_cart", user_id=user_id, correlation_id=correlation_id)

        return success_response(200, {
            'message': 'Cart cleared',
            'user_id': user_id
        }, correlation_id)

    except Exception as e:
        logger.exception("Failed to clear cart")
        return error_response(500, f"Failed to clear cart: {str(e)}", correlation_id)
